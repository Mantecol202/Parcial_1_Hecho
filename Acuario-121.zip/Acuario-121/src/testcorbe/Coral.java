public class Coral extends Especie {
    private double profundidadIdeal;

    public Coral(String nombre, String tanque, TipoAgua tipoAgua, double profundidadIdeal) {
        super(nombre, tanque, tipoAgua);
        this.profundidadIdeal = profundidadIdeal;
    }

    @Override
    public String getInformacion() {
        return nombre + " | " + tanque + " | " + tipoAgua + " | Profundidad: " + profundidadIdeal + "m";
    }
}
