public abstract class Especie {
    protected String nombre;
    protected String tanque;
    protected TipoAgua tipoAgua;

    public Especie(String nombre, String tanque, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }

    public abstract String getInformacion();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Especie otra = (Especie) obj;
        return this.nombre.equals(otra.nombre) && this.tanque.equals(otra.tanque);
    }
}
