import java.util.ArrayList;

public class Acuario {
    private ArrayList<Especie> listaEspecies;
    private String nombreAcuario;

    public Acuario(String nombreAcuario){
        this.nombreAcuario = nombreAcuario;
        this.listaEspecies = new ArrayList<>();
    }

    public void agregarEspecie(Especie e){
        for (Especie especieExistente : this.listaEspecies) {
            if (especieExistente.equals(e)) {
                throw new ExceptionEspecieYaExistente("ERROR. Ya existe esa especie en el acuario.");
            }
        }
        this.listaEspecies.add(e);
    }

    public String mostrarEspecies(){
        String resultado = "Especies en el acuario " + this.nombreAcuario + ":\n";
        for (Especie e : this.listaEspecies) {
            resultado += e.getInformacion() + "\n";
        }
        return resultado;
    }

    public void alimentarEspecies(){
        for (Especie e : this.listaEspecies){
            if (e instanceof Alimentable){
                Alimentable alimentable = (Alimentable) e;
                System.out.println(alimentable.alimentar());
            } else {
                System.out.println("La especie " + e.nombre + " no puede/necesita ser alimentada.");
            }
        }
    }

    public void filtrarPorTipoAgua(TipoAgua tipo){
        for (Especie e : this.listaEspecies){
            if (e.tipoAgua == tipo){
                System.out.println(e.getInformacion());
            }
        }
    }
}
