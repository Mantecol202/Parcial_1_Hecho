public class Molusco extends Especie implements Alimentable {
    private String tipoConcha;

    public Molusco(String nombre, String tanque, TipoAgua tipoAgua, String tipoConcha) {
        super(nombre, tanque, tipoAgua);
        this.tipoConcha = tipoConcha;
    }

    @Override
    public String getInformacion() {
        return nombre + " | " + tanque + " | " + tipoAgua + " | Concha: " + tipoConcha;
    }

    @Override
    public String alimentar() {
        return "Alimentando al molusco: " + nombre;
    }
}
