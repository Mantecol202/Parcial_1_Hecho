public class Main {
    public static void main(String [] args){
        Pez p1 = new Pez("Pez Payaso", "T1", TipoAgua.AGUA_SALADA, 22);
        Pez p2 = new Pez("Pez Payaso", "T1", TipoAgua.AGUA_DULCE, 50);
        Molusco m1 = new Molusco("Nautilo perlado", "T1", TipoAgua.AGUA_DULCE, "Rojo");
        Coral c1 = new Coral("Cerebro", "T4", TipoAgua.AGUA_DULCE, 22.3);

        Acuario acuario1 = new Acuario("Acuario azul");
        try{
            acuario1.agregarEspecie(p1);
            acuario1.agregarEspecie(m1);
            acuario1.agregarEspecie(c1);
            acuario1.agregarEspecie(p2);
            System.out.println("SE agregaron todos los especies al acuario");
        } catch(ExceptionEspecieYaExistente e){
            System.out.println(e.getMessage());
        }

        System.out.println("----------------ESPECIES DEL ACUARIO----------------");
        System.out.println(acuario1.mostrarEspecies());

        System.out.println("----------------ALIMENTANDO ESPECIES DEL ACUARIO----------------");
        acuario1.alimentarEspecies();

        System.out.println("----------------FILTRANDO ESPECIES DEL ACUARIO POR TIPO DE AGUA----------------");
        acuario1.filtrarPorTipoAgua(TipoAgua.AGUA_SALADA);

    }
}
