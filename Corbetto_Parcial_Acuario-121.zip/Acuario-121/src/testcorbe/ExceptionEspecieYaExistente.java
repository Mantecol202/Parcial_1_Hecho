public class ExceptionEspecieYaExistente extends RuntimeException {
    public ExceptionEspecieYaExistente(String mensaje) {
        super(mensaje);
    }
}
