public interface Alimentable {
    String alimentar();
}
