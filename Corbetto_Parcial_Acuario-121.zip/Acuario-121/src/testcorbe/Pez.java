public class Pez extends Especie implements Alimentable {
    private int longitud;

    public Pez(String nombre, String tanque, TipoAgua tipoAgua, int longitud) {
        super(nombre, tanque, tipoAgua);
        this.longitud = longitud;
    }

    @Override
    public String getInformacion() {
        return nombre + " | " + tanque + " | " + tipoAgua + " | Longitud: " + longitud + "cm";
    }

    @Override
    public String alimentar() {
        return "Alimentando al pez: " + nombre;
    }
}
